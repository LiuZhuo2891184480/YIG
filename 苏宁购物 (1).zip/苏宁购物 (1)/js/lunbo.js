
$(function(){
	$(".lunbo_set").hover(function(){
		$(".arrowRight,.arrowLeft").show();
	}).mouseleave(function(){
		$(".arrowRight,.arrowLeft").hide();
	})
})


          

var and=new Array("img/未标题-4.gif","img/未标题-3.gif","img/未标题-4.gif","img/未标题-1.gif","img/未标题-2.gif","img/未标题-3.gif","img/未标题-4.gif","img/未标题-1.gif");
var and1=0;

$(".arrowRight").click(function(){
	if(and1==and.length-1){
		and1=-1;
	}else{
		and1++;
		 $(".lunbo_set").css("background","url("+and[and1]+")no-repeat").css("background-position","20px,40px");
		  $(".lunbo_set li:nth-of-type("+(and1+1)+")").css("background","orange");
		  $(".lunbo_set li:nth-of-type("+(and1+1)+")").siblings().css("background","#333333");
	}
})
$(".arrowLeft").click(function(){
	if(and1==0){
		 
	}else{
		and1--;
		 $(".lunbo_set").css("background","url("+and[and1]+")no-repeat").css("background-position","20px,40px");
		  $(".lunbo_set li:nth-of-type("+(and1-1)+")").css("background","orange");
		  $(".lunbo_set li:nth-of-type("+(and1-1)+")").siblings().css("background","#333333");
	}
})

$(function(){
	
	setTimeout(andse(),1000);
	alert(1)
})



function andse(){
	if(and1==and.length-1){
		and1=-1;
	}else{
		and1++;
		 $(".lunbo_set").css("background","url("+and[and1]+")no-repeat").css("background-position","20px,40px");
		  $(".lunbo_set li:nth-of-type("+(and1+1)+")").css("background","orange");
		  $(".lunbo_set li:nth-of-type("+(and1+1)+")").siblings().css("background","#333333");
	}
}
