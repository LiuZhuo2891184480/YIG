
//导航栏二级菜单
$(document).ready(function(){
		$("#diyi").mouseenter(function(){
		    $("#sda").show();	
		    $("#bai").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai").hide();
		})
	})

$(document).ready(function(){
		$("#shangjia").mouseenter(function(){
		    $(".Top_top_left4").show();	
		    $("#bai1").show();
		}).mouseleave(function(){
		$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai1").hide();
		})
	})

$(document).ready(function(){
		$("#shangjia1").mouseenter(function(){
		    $(".Top_top_left5").show();	
		    $("#bai2").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();	
			$("#bai2").hide();
		})
	})

//导航栏右边的二级菜单

$(document).ready(function(){
	$(".Top_left3 .Top_top_left22").hover(function(){
		$(this).css("background","#FFFFFF")
	}).mouseleave(function(){
		$(this).css("background","#f5f5f5")
	})
})

$(document).ready(function(){
		$("#Deng1").mouseenter(function(){
		    $("#Deng").show(200);	
		    $("#bai3").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai3").hide();
		})
	})

$(document).ready(function(){
		$("#Deng2id").hover(function(){
		    $("#Deng2").show(200);	
		    $("#bai4").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai4").hide();
		})
	})

$(document).ready(function(){
		$("#Deng3id").hover(function(){
		    $("#Deng3").show(200);	
		    $("#bai5").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();	
			$("#bai5").hide();
		})
	})

$(document).ready(function(){
		$("#Deng4id").hover(function(){
		    $("#Deng4").show(200);	
		    $("#bai7").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai7").hide();
		})
	})

$(document).ready(function(){
		$("#Deng5id").hover(function(){
		    $("#Deng5").show(200);	
		    $("#bai10").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai10").hide();
		})
	})


	
//$(function(){
//	$(".set_and2").hover(function(){
//		$(this).css("background","#FFFFFF");
//	})
//})


$(document).ready(function(){
	$(".set_and2").hover(function(){
		$(this).css("background","#FFFFFF");
		$(this).find("a").css("color","black")
		$(this).find("div").show();
	}).mouseleave(function(){
		$(this).css("background","black");
		$(this).find("div").hide();
		$(this).find("a").css("color","#FFFFFF")
	})
})



$(function(){
    $("#manml").css("background","#f46b6b").css("color","#FFFFFF").css("padding","3px 7px").css("border-radius","25px");
	$(".Yes_ok a").toggle(function(){
		$(".Yes_ok a").css("background","#FFFFFF").css("color","black").css("padding","3px 7px").css("border-radius","25px");
		$(this).css("background","#f46b6b").css("color","#FFFFFF").css("padding","3px 7px").css("border-radius","25px");
	},function(){
		$(this).css("background","#FFFFFF").css("color","black").css("padding","3px 7px").css("border-radius","25px");
	})
	
	$(".mansd").show();
	$("#manml").click(function(){
		$(".mansd1,.mansd2,.mansd3").hide();
		$(".mansd").show();
	})
	$("#manm2").click(function(){
		$(".mansd,.mansd2,.mansd3").hide();
		$(".mansd1").show();
	})
	$("#manm3").click(function(){
		$(".mansd1,.mansd,.mansd3").hide();
		$(".mansd2").show();
	})
	$("#manm4").click(function(){
		$(".mansd1,.mansd2,.mansd").hide();
		$(".mansd3").show();
	})
	
	$(".toubus img").click(function(){
		$(".toubus").hide();
	})
	
	
	$(".fense").mouseenter(function(){
		$(this).css("background","#ff9900").next().css("color","#FFFFFF");
	}).mouseleave(function(){
		$(this).css("background","#FFFFFF").css("color","black");
	})
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
})

























		  var PicTotal = 5;// 当前图片总数

    var CurrentIndex;// 当前鼠标点击图片索引

    var ToDisplayPicNumber = 0;// 自动播放时的图片索引

    $("div.LunBo div.LunBoNum span").click(DisplayPic);

    function DisplayPic() {

// 测试是父亲的第几个儿子

        CurrentIndex = $(this).index();

// 删除所有同级兄弟的类属性

        $(this).parent().children().removeClass("CurrentNum")

// 为当前元素添加类

        $(this).addClass("CurrentNum");

// 隐藏全部图片

        var Pic = $(this).parent().parent().children("ul");

        $(Pic).children().hide();

// 显示指定图片

        $(Pic).children("li").eq(CurrentIndex).show();

    }

    function PicNumClick() {

        $("div.LunBo div.LunBoNum span").eq(ToDisplayPicNumber).trigger("click");

        ToDisplayPicNumber = (ToDisplayPicNumber + 1) % PicTotal;

        setTimeout("PicNumClick()",1000);

    }

    setTimeout("PicNumClick()",1000);
	
