//导航栏二级菜单
$(document).ready(function(){
		$("#diyi").hover(function(){
		    $("#sda").show(200);	
		    $("#bai").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai").hide();
		})
	})

$(document).ready(function(){
		$("#shangjia").hover(function(){
		    $(".Top_top_left4").show(200);	
		    $("#bai1").show();
		}).mouseleave(function(){
		$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai1").hide();
		})
	})

$(document).ready(function(){
		$("#shangjia1").hover(function(){
		    $(".Top_top_left5").show(200);	
		    $("#bai2").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();	
			$("#bai2").hide();
		})
	})

//导航栏右边的二级菜单

$(document).ready(function(){
	$(".Top_left3 .Top_top_left22").hover(function(){
		$(this).css("background","#FFFFFF")
	}).mouseleave(function(){
		$(this).css("background","#f5f5f5")
	})
})

$(document).ready(function(){
		$("#Deng1").hover(function(){
		    $("#Deng").show(200);	
		    $("#bai3").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai3").hide();
		})
	})

$(document).ready(function(){
		$("#Deng2id").hover(function(){
		    $("#Deng2").show(200);	
		    $("#bai4").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai4").hide();
		})
	})

$(document).ready(function(){
		$("#Deng3id").hover(function(){
		    $("#Deng3").show(200);	
		    $("#bai5").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();	
			$("#bai5").hide();
		})
	})

$(document).ready(function(){
		$("#Deng4id").hover(function(){
		    $("#Deng4").show(200);	
		    $("#bai7").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai7").hide();
		})
	})

$(document).ready(function(){
		$("#Deng5id").hover(function(){
		    $("#Deng5").show(200);	
		    $("#bai10").show();
		}).mouseleave(function(){
			$(".Top_top_left4").hide();	
			$(".Top_top_left5").hide();	
			$("#Deng").hide();	
			$("#sda").hide();
			$("#Deng2").hide();	
			$("#Deng3").hide();	
			$("#Deng4").hide();	
			$("#Deng5").hide();
			$("#bai10").hide();
		})
	})




$(function(){
	$(".zhuti3 a:nth-of-type(2)").click(function(){
		$(".cang").show();
	})
	
	$(".zhuti3").mouseleave(function(){
		$(".cang").hide();
	})
})


$(function(){
	$(".select li:nth-of-type(1)").css("border-bottom","5px solid #ffbc35");
	$(".select li").mouseenter(function(){
		$(".select li").css("border-bottom","0px solid #ffbc35");
		$(this).css("border-bottom","5px solid #ffbc35");
	})	
})
