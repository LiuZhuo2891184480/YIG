
$(function(){
	
	//验证账号
	$("#name").blur(function(){
		if($("#name").val()==""){
			$(".p1").html("账号不能为空")
		}else if($("#name").val().length<10){
			$(".p1").html("账号长度要大于10")
		}
		
	})
	
	$("#pass").blur(function(){
		if($("#pass").val()==""){
			$(".p3").html("密码不能为空");
		}else if($("#name").val().length<10){
			$(".p1").html("密码长度要大于10")
		}
		
	})
	
})
