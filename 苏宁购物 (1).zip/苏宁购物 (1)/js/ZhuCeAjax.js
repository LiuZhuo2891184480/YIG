$(function(){
	$(".mansndma").blur(function(){
		$.ajax({
			type:"get",
			datetype:'Json',
			url:"Ajax/fhgj.json",
			success:function(textname){
				var asd=$(".mansndma").val();
				if(textname[1].tag_name==asd){
					alert("账号已存在")
				}else{
					alert("账号可以使用")
				}
			},
			error:function(){
				
			}
		});
	})
})
